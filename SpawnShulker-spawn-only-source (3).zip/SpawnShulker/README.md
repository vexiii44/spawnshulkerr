# SpawnShulker 1.1.0

Paper plugin project. Right-clicking a placed shulker inside the WorldGuard region whose ID is exactly `spawn` opens a read-only 27-slot preview GUI. Outside that region, shulkers behave normally.

## Requirements
- Paper API matching the server version.
- WorldGuard installed and loaded.
- Java 25 and Maven to build this project.

## Build
Run `mvn package`. The output JAR should be `target/SpawnShulker-1.1.0.jar`.

## Install
1. Back up the server.
2. Ensure WorldGuard is installed and working.
3. Stop the server.
4. Put the built JAR into `plugins`.
5. Start the server and check the console.

The plugin checks for a WorldGuard region ID exactly equal to `spawn` (case-insensitive). Use `/rg info spawn` to confirm the region ID.

## Notes
- This project source has not been compiled or tested against the user's exact Paper build.
- WorldGuard 7.0.14 is declared as a provided build dependency. If that release does not support the server's Paper/Minecraft API version, use a compatible WorldGuard release and update the dependency version before building.
- The preview is a snapshot. Close and reopen to refresh changed contents.
- This plugin does not itself prevent breaking or moving the shulker block; retain WorldGuard build protection.
